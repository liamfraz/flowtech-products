# Power Automate Beginner's Blueprint

**From Zero to Automated — Master Power Automate in 8 Modules**

## What's Included

- `power-automate-beginners-blueprint.pdf` — 45+ page comprehensive course

## What You'll Learn

| Module | Topics Covered |
|--------|---------------|
| 1 | Introduction to Power Automate — triggers, actions, connectors |
| 2 | Your First Flow — step-by-step walkthrough |
| 3 | Working with Data — variables, expressions, arrays |
| 4 | Conditions and Loops — branching logic, Apply to Each |
| 5 | Connectors Deep Dive — SharePoint, Teams, Outlook, Forms |
| 6 | Error Handling — Scope blocks, try/catch patterns |
| 7 | Advanced Expressions — JSON parsing, string manipulation, date math |
| 8 | ALM Best Practices — Solutions, environments, deployment |

## How to Use

1. Open the PDF in any PDF reader (Adobe Acrobat, browser, or mobile)
2. Work through each module in order — each builds on the previous
3. Complete the hands-on exercises in Power Automate as you go
4. Use the expression reference tables at the back for quick lookups

## Requirements

- Microsoft 365 account with Power Automate access
- No prior automation experience needed — this starts from scratch

## Support

Questions? Email support@flowtechadvisory.com

---
*Thank you for your purchase! If this helped you, please leave a review.*
