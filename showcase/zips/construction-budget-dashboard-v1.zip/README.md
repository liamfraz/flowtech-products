# Construction Budget Dashboard

**Professional Excel Dashboard for Construction Project Budget Tracking**

## What's Included

- `construction-budget-dashboard.xlsx` — Pre-built Excel dashboard with charts and formulas

## Features

- **Project Summary Dashboard** — Budget vs Actual comparison at a glance
- **Monthly Cost Breakdown** — Track spend across 6 categories:
  - Labour
  - Materials
  - Equipment
  - Subcontractors
  - Overheads
  - Contingency
- **Variance Charts** — Auto-updating bar charts with conditional formatting (green = under, red = over)
- **Auto-calculating formulas** — SUM, percentage variance, and running totals
- **Print-ready formatting** — Professional layout ready for client/stakeholder reporting

## How to Use

1. Open in Excel Desktop or Excel Online
2. Enter your project budget in the **Budget** column (yellow cells)
3. Enter actual costs as they occur in the **Actual** column
4. The dashboard and charts update automatically
5. Use **File > Print** for a professional A4 report

## Requirements

- Microsoft Excel 2016 or later (Desktop or Online)
- Works with Office 365, Microsoft 365, and standalone Excel

## Support

Questions? Email support@flowtechadvisory.com

---
*Thank you for your purchase! If this helped you, please leave a review.*
